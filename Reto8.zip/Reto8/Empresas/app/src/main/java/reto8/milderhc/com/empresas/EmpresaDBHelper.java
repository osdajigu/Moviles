package reto8.milderhc.com.empresas;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class EmpresaDBHelper extends SQLiteOpenHelper {
    private static int version = 1;
    private static String name = "Empresas";
    private static SQLiteDatabase.CursorFactory factory = null;

    public EmpresaDBHelper(Context context) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i(this.getClass().toString(), "Creando base de datos");

        db.execSQL("CREATE TABLE EMPRESA(" +
                " _id INTEGER PRIMARY KEY," +
                " emp_nombre TEXT NOT NULL, " +
                " emp_url TEXT, " +
                " emp_telefono TEXT," +
                " emp_email TEXT," +
                " emp_productos TEXT," +
                " emp_clasificacion TEXT)");

        db.execSQL("CREATE UNIQUE INDEX emp_nombre ON EMPRESA(emp_nombre ASC)");

        Log.i(this.getClass().toString(), "Tabla EMPRESA creada");

        db.execSQL("INSERT INTO EMPRESA(_id, emp_nombre) VALUES(1,'Empresa1')");
        db.execSQL("INSERT INTO EMPRESA(_id, emp_nombre) VALUES(2,'Empresa2')");
        db.execSQL("INSERT INTO EMPRESA(_id, emp_nombre) VALUES(3,'Empresa3')");
        db.execSQL("INSERT INTO EMPRESA(_id, emp_nombre) VALUES(4,'Empresa4')");
        db.execSQL("INSERT INTO EMPRESA(_id, emp_nombre) VALUES(5,'Empresa5')");
        db.execSQL("INSERT INTO EMPRESA(_id, emp_nombre) VALUES(6,'Empresa6')");
        db.execSQL("INSERT INTO EMPRESA(_id, emp_nombre) VALUES(7,'Empresa7')");

        Log.i(this.getClass().toString(), "Datos iniciales EMPRESA insertados");

        Log.i(this.getClass().toString(), "Base de datos creada");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


    }

}
