package tictactoe.unal.edu.co.osmhelloworld20;

import android.app.Activity;
import android.os.Bundle;

import org.osmdroid.api.IMapController;
import org.osmdroid.views.MapView;

public class MainActivity extends Activity {


    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MapView myOpenMapView = (MapView)findViewById(R.id.map);
        myOpenMapView.setBuiltInZoomControls(true);
        IMapController myMapController = myOpenMapView.getController();
        myMapController.setZoom(4);
        myOpenMapView.setMultiTouchControls(true);
    }

}