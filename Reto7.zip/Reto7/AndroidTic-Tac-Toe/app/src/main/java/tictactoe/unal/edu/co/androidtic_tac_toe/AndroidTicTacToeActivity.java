package tictactoe.unal.edu.co.androidtic_tac_toe;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import edu.harding.tictactoe.BoardView;
import edu.harding.tictactoe.TicTacToeGame;

public class AndroidTicTacToeActivity extends AppCompatActivity {

    static final int DIALOG_QUIT_ID = 1;
    static final int DIALOG_ABOUT = 2;

    private TicTacToeGame gameStatus;
    private TextView infoTextView;
    private boolean gameOver;

    private int humanWins, computerWins, ties;
    private TextView humanTextView, computerTextView, tiesTextView;

    private BoardView boardView;

    private boolean humanStarts;
    private boolean mSoundOn;

    Handler handler;
    private SharedPreferences mPrefs;

    MediaPlayer mHumanMediaPlayer;
    MediaPlayer mComputerMediaPlayer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        gameStatus = new TicTacToeGame();

        mPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        mSoundOn = mPrefs.getBoolean("sound", true);
        String difficultyLevel = mPrefs.getString("difficulty_level",
                getResources().getString(R.string.difficulty_harder));
        if (difficultyLevel.equals(getResources().getString(R.string.difficulty_easy)))
            gameStatus.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
        else if (difficultyLevel.equals(getResources().getString(R.string.difficulty_harder)))
            gameStatus.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
        else
            gameStatus.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);


        mPrefs = PreferenceManager.getDefaultSharedPreferences(this);

        humanWins = mPrefs.getInt("mHumanWins", 0);
        computerWins = mPrefs.getInt("mComputerWins", 0);
        ties = mPrefs.getInt("mTies", 0);

        boardView = (BoardView) findViewById(R.id.board);
        boardView.setGame(gameStatus);

        boardView.setOnTouchListener(touchListener);

        infoTextView = (TextView) findViewById(R.id.information);

        humanTextView = (TextView) findViewById(R.id.count_human);
        tiesTextView = (TextView) findViewById(R.id.count_ties);
        computerTextView = (TextView) findViewById(R.id.count_computer);

        humanStarts = true;
        if (savedInstanceState == null) {
            startNewGame();
        }
        else {
            // Restore the game's state
            gameStatus.setBoardState(savedInstanceState.getCharArray("board"));
            gameOver = savedInstanceState.getBoolean("mGameOver");
            infoTextView.setText(savedInstanceState.getCharSequence("info"));
            humanWins = savedInstanceState.getInt("mHumanWins");
            computerWins = savedInstanceState.getInt("mComputerWins");
            ties = savedInstanceState.getInt("mTies");
            humanStarts = savedInstanceState.getBoolean("mGoFirst");
            humanTurn = savedInstanceState.getBoolean("turn");
        }

        displayScores();

        handler = new Handler();
    }

    @Override
    protected void onStop() {
        super.onStop();

        // Save the current scores
        SharedPreferences.Editor ed = mPrefs.edit();
        ed.putInt("mHumanWins", humanWins);
        ed.putInt("mComputerWins", computerWins);
        ed.putInt("mTies", ties);
        ed.commit();
    }


    private void displayScores() {
        humanTextView.setText(Integer.toString(humanWins));
        computerTextView.setText(Integer.toString(computerWins));
        tiesTextView.setText(Integer.toString(ties));
    }

    @Override
    protected void onResume() {
        super.onResume();

        mHumanMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.sword);
        mComputerMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.swish);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mHumanMediaPlayer.release();
        mComputerMediaPlayer.release();
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putCharArray("board", gameStatus.getBoardState());
        outState.putBoolean("mGameOver", gameOver);
        outState.putInt("mHumanWins", Integer.valueOf(humanWins));
        outState.putInt("mComputerWins", Integer.valueOf(computerWins));
        outState.putInt("mTies", Integer.valueOf(ties));
        outState.putCharSequence("info", infoTextView.getText());
        outState.putBoolean("mGoFirst", humanStarts);
        outState.putBoolean("turn", humanTurn);
    }


    private boolean humanTurn;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.i("ActividadPrincipal", "olakase");
        if (requestCode == RESULT_CANCELED) {
            // Apply potentially new settings

            mSoundOn = mPrefs.getBoolean("sound", true);
            //Log.i("MainActivity", mSoundOn);
            String difficultyLevel = mPrefs.getString("difficulty_level",
                    getResources().getString(R.string.difficulty_harder));

            if (difficultyLevel.equals(getResources().getString(R.string.difficulty_easy)))
                gameStatus.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
            else if (difficultyLevel.equals(getResources().getString(R.string.difficulty_harder)))
                gameStatus.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
            else
                gameStatus.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_game:
                startNewGame();
                return true;
            case R.id.settings:
                startActivityForResult(new Intent(this, Settings.class), 0);
                return true;
            case R.id.quit:
                showDialog(DIALOG_QUIT_ID);
                return true;
            case R.id.about:
                showDialog(DIALOG_ABOUT);
                return true;
            case R.id.reset:
                ties = 0;
                humanWins = 0;
                computerWins = 0;
                startNewGame();
                return true;
        }
        return false;
    }


    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        switch(id) {
            case DIALOG_QUIT_ID:
                // Create the quit confirmation dialog

                builder.setMessage(R.string.quit_question)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                AndroidTicTacToeActivity.this.finish();
                            }
                        })
                        .setNegativeButton(R.string.no, null);
                dialog = builder.create();

                break;
            case DIALOG_ABOUT:
                Context context = getApplicationContext();
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
                View layout = inflater.inflate(R.layout.about_dialog, null);
                builder.setView(layout);
                builder.setPositiveButton("OK", null);
                dialog = builder.create();
        }


        return dialog;
    }


    private void updateStatistics() {
        humanTextView.setText( humanWins + "" );
        tiesTextView.setText( ties + "" );
        computerTextView.setText( computerWins + "" );
    }


    private void startNewGame() {
        gameStatus.clearBoard();
        boardView.invalidate();   // Redraw the board

        gameOver = false;
        humanTurn = true;
        // reset to initial values

        if(!humanStarts) {
            int move = gameStatus.getComputerMove();
            setMove(TicTacToeGame.COMPUTER_PLAYER, move);
            infoTextView.setText(R.string.turn_human);
        } else {
            // Human goes first
            infoTextView.setText(R.string.first_human);
        }

        humanStarts = !humanStarts;
    }

    private void setMove(char player, int location) {
        gameStatus.setMove(player, location);
        boardView.invalidate();
    }

    int winner;

    void updateInfo() {
        gameOver |= winner != 0;

        if (winner == 0)
            infoTextView.setText(R.string.turn_human);
        else if (winner == 1) {
            infoTextView.setText(R.string.result_tie);
            ++ties;
        }
        else if (winner == 2) {
            String defaultMessage = getResources().getString(R.string.result_human_wins);
            infoTextView.setText(mPrefs.getString("victory_message", defaultMessage));
            ++humanWins;
        }
        else {
            infoTextView.setText(R.string.result_computer_wins);
            ++computerWins;
        }

        if(gameOver)
            updateStatistics();
    }

    private View.OnTouchListener touchListener = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {

            // Determine which cell was touched
            int col = (int) event.getX() / boardView.getBoardCellWidth();
            int row = (int) event.getY() / boardView.getBoardCellHeight();
            int location = row * 3 + col;

            if(!gameOver && humanTurn == true && gameStatus.getBoardOccupant(row, col) == TicTacToeGame.OPEN_SPOT) {
                setMove(TicTacToeGame.HUMAN_PLAYER, location);
                if(mSoundOn)
                    mHumanMediaPlayer.start();
                humanTurn = false;

                winner = gameStatus.checkForWinner();
                if(winner == 0) {
                    infoTextView.setText(R.string.turn_computer);

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            int move = gameStatus.getComputerMove();
                            setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                            if(mSoundOn)
                                mComputerMediaPlayer.start();
                            humanTurn = !humanTurn;
                            infoTextView.setText(R.string.turn_human);

                            winner = gameStatus.checkForWinner();


                            updateInfo();
                        }
                    }, 1000);

                } else {
                    updateInfo();
                }


            }

            // So we aren't notified of continued events when finger is moved
            return false;
        }
    };



    /*

    private class ButtonClickListener implements View.OnClickListener {
        int location;

        public ButtonClickListener(int location) {
            this.location = location;
        }

        @Override
        public void onClick(View v) {
            if(!gameOver && boardButtons[location].isEnabled()) {

                setMove(TicTacToeGame.HUMAN_PLAYER, location);

                int winner = gameStatus.checkForWinner();
                if(winner == 0) {
                    infoTextView.setText(R.string.turn_computer);
                    int move = gameStatus.getComputerMove();
                    setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                    winner = gameStatus.checkForWinner();
                }

                gameOver |= winner != 0;

                if (winner == 0)
                    infoTextView.setText(R.string.turn_human);
                else if (winner == 1) {
                    infoTextView.setText(R.string.result_tie);
                    ++ties;
                }
                else if (winner == 2) {
                    infoTextView.setText(R.string.result_human_wins);
                    ++humanWins;
                }
                else {
                    infoTextView.setText(R.string.result_computer_wins);
                    ++computerWins;
                }

                if(gameOver)
                    updateStatistics();
            }
        }
    }
    */


}